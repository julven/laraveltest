<?php $__env->startSection('component'); ?>
    <div class="row">
        <div class="col s12 m10 l8 xl7">
            <div class="card" style="min-width: 350px">
                <div class="card-content">
                    <div class="card-title">
                        Form
                        <?php if(session()->has('success')): ?>
                        <span style="float:right" class="green-text"><?php echo e(session()->get('success')); ?></span>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                        <span style="float:right" class="red-text">Please fill up the required fields!</span>
                        <?php endif; ?>
                        
                    </div>
                    <hr>
                    <form  method="POST"  enctype="multipart/form-data">
                        <?php if($type=="edit"): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <div style="max-width: 400px">

                            <label for="fname">First Name</label>
                            <input 
                            autocomplete="off" 
                            id="fname" 
                            name="fname" 
                            type="text" 
                            class="<?php echo e($errors->has('fname') ? 'invalid' : ''); ?>" 
                            value="<?php echo e($user->fname ?? old('fname', '')); ?>">
                        
                            <label for="lname">Last Name</label>
                            <input 
                            autocomplete="off" 
                            id="lname" 
                            name="lname" 
                            type="text" 
                            class="<?php echo e($errors->has('lname') ? 'invalid' : ''); ?>" 
                            value="<?php echo e($user->lname ?? old('lname', '')); ?>">
                        
                            <label for="bday">Birthday</label>
                            <input 
                            autocomplete="off" id="bday" 
                            name="bday" type="text" 
                            class="<?php echo e($errors->has('bday') ? 'invalid' : ''); ?>" 
                            value="<?php echo e($user->bday ?? old('bday', '')); ?>">
                        
                            <label for="gender" >Gender</label>
                            <br>
                            <label style="padding-right: 5px">
                                <input 
                                name="gender" 
                                class="gender" 
                                value="male" 
                                type="radio" 
                                <?php echo e((old('gender') != null && old('gender') == 'male')?'checked': ''); ?>

                                <?php echo e($type == 'edit' && $user->gender == 'male' ? 'checked' : '' ?? ''); ?>/>
                                <span class="<?php echo e($errors->has('gender') ? 'red-text' : ''); ?>">Male </span>
                            </label>
                            <label style="padding-right: 5px">
                                <input 
                                name="gender" class="gender" 
                                value="female" 
                                type="radio"  
                                <?php echo e((old('gender') != null  && old()['gender'] == 'female')?'checked': ''); ?>

                                <?php echo e($type == 'edit' && $user->gender == 'female' ? 'checked' : '' ?? ''); ?>/>
                                <span class="<?php echo e($errors->has('gender') ? 'red-text' : ''); ?>">Female</span>
                            </label>
                        
                            <?php if($type == 'add'): ?>
                            <div class="file-field input-field">
                                <div class="btn">
                                    <span>File</span>
                                    <input 
                                    type="file" 
                                    name="image" 
                                    id="image">
                                </div>
                                <div class="file-path-wrapper">
                                    <input 
                                    class="file-path 
                                    <?php echo e($errors->has('image') ? 'invalid' : ''); ?>" 
                                    type="text" >
                                </div>
                            </div>  
                            <?php endif; ?>

                            <?php if($type == 'edit'): ?>
                                <div style="width: 100px; height:100px; margin: 10px 0px; border: 1px solid lightgray">
                                    <img  id="imgprev" src="<?php echo e(asset($user->image)); ?>" alt="<?php echo e($user->image); ?>" style="width: 100%;height:100%">
                                    <input 
                                    hidden
                                    type="file" 
                                    name="image" 
                                    id="image">
                                </div>
                                <button class="btn waves-effect btn-small" style="width: 100px" id="imgchange">Change</button>
                            <?php endif; ?>
                           
                        </div>
                        <?php if($type == 'add'): ?>
                            <div style="text-align: right">
                                <button class="btn waves-effect" type="submit">Add</button>&nbsp;
                                <a class="btn waves-effect" href="<?php echo e(url()->previous()); ?>">Back</a>
                            </div>
                        <?php endif; ?>
                        <?php if($type == 'edit'): ?>
                        <div style="text-align: right">
                            <button class="btn waves-effect" type="submit">Edit</button>&nbsp;
                        <a class="btn waves-effect" href="<?php echo e(url()->previous()); ?>">Back</a>
                        </div>
                       
                        <?php endif; ?>
                        
                    </form>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CONDOR-ASUS\Desktop\laravel\serverjwt\resources\views/components/user_form.blade.php ENDPATH**/ ?>