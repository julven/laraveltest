<?php $__env->startSection('component'); ?>
    <div class="row">
        <div class="col s10 m10 l9 xl7">
            <div class="card" style="min-width: 400px">
                <div class="card-content"  >
                    <div class="card-title">List <a class="waves-effect btn" style="float:right" href="/add">New</a></div>
                    <hr>
                    <div style="min-height: 600px">
                        <table>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div style="width: 100px; height: 100px; border: 1px solid lightgray">
                                            <img src="<?php echo e(asset($user->image)); ?>" alt="" style="width: 100%; height:100%;">
                                            
                                        </div>
                                        
                                        
                                    </td>
                                    <td>
                                        <div style="line-height: 20px; max-width: 160px">
                                            <small>name:</small>
                                            <span style="float: right"> <?php echo e($user->fname); ?> <?php echo e($user->lname); ?></span><br>
                                            <small>gender:</small>
                                            <span style="float: right"> <?php echo e($user->gender); ?> </span><br>
                                            <small>birthday:</small>
                                            <span style="float: right"> <?php echo e($user->bday); ?></span><br>
                                        </div>
                                    </td>
                                    <td>
                                    <a href="/edit/<?php echo e($user->id); ?>" class="btn waves-effect" style="width: 100%;margin-bottom: 5px">Edit</a><br>
                                        <button class="btn waves-effect" style="width: 100%" onclick="deletes(<?php echo e($user->id); ?>)">Delete</button>
                                        <form method="POST" id="userdel_<?php echo e($user->id); ?>">
                                            <?php echo method_field("DELETE"); ?>
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($user->id); ?>" name="id">
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
    
                              
                            </tbody>
                        </table>
                    </div>
                    

                    <ul class="pagination" style="text-align: center">
                        <li class="<?php echo e($users->currentPage() == 1 ? 'disabled': 'waves-effect '); ?>"><a href="<?php echo e($users->previousPageUrl()); ?>"><i class="material-icons">chevron_left</i></a></li>
                        <li ><a ><?php echo e($users->currentPage()); ?></a></li>
                        <li ><a >/</a></li>
                        <li ><a ><?php echo e($users->lastPage()); ?></a></li>
                        <li class="<?php echo e($users->currentPage() == $users->lastPage() ? 'disabled': 'waves-effect '); ?>" ><a href="<?php echo e($users->nextPageUrl()); ?>"><i class="material-icons">chevron_right</i></a></li>
                    </ul>
                
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CONDOR-ASUS\Desktop\laravel\serverjwt\resources\views/components/list.blade.php ENDPATH**/ ?>