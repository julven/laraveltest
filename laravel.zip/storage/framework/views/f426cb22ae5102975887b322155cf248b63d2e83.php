<?php $__env->startSection('component'); ?>
    
    
    <div class="row">
        <div class="col s12 m10 l8 xl6">
            <div class="card">
                <div class="card-content">
                    <?php if(!Auth::check()): ?>

                    <span class="card-title">Login</span>
                    <form action="/login" method="POST">
                        <?php echo csrf_field(); ?>
                    <div class="input-field ">
                        <input placeholder="Placeholder" id="username" type="text" name="username" class="<?php echo e($errors->any() ? 'invalid' : ''); ?>">
                            <label for="username">Username</label>
                        </div>

                        <div class="input-field">
                            <input placeholder="Placeholder" id="password" name="password" type="password" class="<?php echo e($errors->any() ? 'invalid' : ''); ?>">
                            <label for="password">Password</label>
                        </div>
                        <?php if($errors->any()): ?>
                            <p class="red-text">Invalid username or password</p>
                        <?php endif; ?>

                        <button class="btn waves-effect" type="submit">Login</button>
                    </form>
                    <?php else: ?>
                    <span class="card-title">Logged in as "<?php echo e(Auth::user()->fname); ?>"</span>
                    <?php endif; ?>
                </div>
                
            </div>
        </div>
    </div>
    <style>
        #username, #password {
            max-width: 350px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CONDOR-ASUS\Desktop\laravel\serverjwt\resources\views/components/login.blade.php ENDPATH**/ ?>