<?php $__env->startSection('component'); ?>
<div class="row">
    <div class="col s12 m9 l8 xl6">
        <div class="card">
            <div class="card-content">
                <div class="card-title">
                    Info
                   <a class="waves-effect btn btn-small" style="float:right" href="<?php echo e(url()->previous()); ?>">Back</a>
                </div>
                <hr>
                <?php if($errors->any() && array_keys($errors->messages())[0] != 'password'): ?>
                    <span style="float:right" class="red-text">Failed to updated info!</span>
                <?php endif; ?>
                <?php if(session()->has('success') && session()->get('type') == 'info'): ?>
                    <span style="float:right" class="green-text"><?php echo e(session()->get('success')); ?></span>
                <?php endif; ?>
                <div style="clear:both"></div>
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" value="info" name="type">
                    <div style="max-width: 300px">
                        <label for="fname">First Name</label>
                        <input placeholder="Placeholder" id="fname" type="text" name="fname" value="<?php echo e($account->fname); ?>">

                        <label for="lname">Last Name</label>
                        <input placeholder="Placeholder" id="lname" type="text" name="lname" value="<?php echo e($account->lname); ?>">

                        
                        <div  style="max-width: 150px">
                            <label for="bday">Birthday</label>
                            <input placeholder="Placeholder" id="bday" type="text" name="bday" value="<?php echo e($account->bday); ?>">

                            <label for="gender">Gender</label>
                            <select type="text" name="gender" id="selgender">
                            
                                <option value="male" <?php echo e($account->gender == "male" ? 'selected' : ''); ?>>Male</option>
                                <option value="female" <?php echo e($account->gender == "female" ? 'selected' : ''); ?>>Female</option>
                                
                            </select>
                        </div> 
                    
                    </div>
                    <button class="btn waves-effect btn-small" type="submit" style="float: right">Update Info</button>
                    <div style="clear:both"></div>
                </form>
                
                <span class="card-title">Account</span>
                <hr>
                <?php if($errors->any() && array_keys($errors->messages())[0] == 'password'): ?>
                    <span style="float:right" class="red-text">Failed to updated pass!</span>
                <?php endif; ?>
                <?php if(session()->has('success') && session()->get('type') == 'pass'): ?>
                    <span style="float:right" class="green-text"><?php echo e(session()->get('success')); ?></span>
                <?php endif; ?>
                <div style="clear:both"></div>
                <label for="username">Username</label>
                                
                <p><b>Admin</b></p>
                
                <label for="password">Password</label>
                <form method="POST">
                    <div class="row">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" value="pass" name="type">
                        <div class="col s10 m6 l6 xl6">
                            <input placeholder="New Password" id="password_new" type="password" name="password_confirmation">
                        </div>
                        <div class="col s10 m6 l6 xl6">
                            <input placeholder="Confirm" id="password_conf" type="password" name="password">
                        </div>

                    </div>
                    <button class="btn waves-effect btn-small" style="float: right">Update Pass</button>
                    <div style="clear:both"></div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CONDOR-ASUS\Desktop\laravel\serverjwt\resources\views/components/account.blade.php ENDPATH**/ ?>