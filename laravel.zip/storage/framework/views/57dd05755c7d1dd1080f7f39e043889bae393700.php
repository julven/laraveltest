<?php $__env->startSection('component'); ?>
    <div class="row">
        <div class="col s12 m7 l6 xl5">
            <div class="card">
                <div class="card-content">
                    <span class="card-title">Summary</span>
                    <hr>
                    <table style="max-width: 230px">
                        <tbody>
                            <tr>
                                <td>Male(s)</td>
                                <td><?php echo e($data['male']); ?></td>
                            </tr>

                            <tr>
                                <td>Female(s)</td>
                                <td><?php echo e($data['female']); ?></td>
                            </tr>

                            <tr>
                                <td>Total</td>
                                <td><?php echo e($data['total']); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CONDOR-ASUS\Desktop\laravel\serverjwt\resources\views/components/home.blade.php ENDPATH**/ ?>